
<?php $__env->startSection('content'); ?>
<div class="content-sticky-footer">

    <div class="col-12 mb-4">
        <div class="card">
            <div class="card-body">
                <p class="text-uppercase font-weight-bold text-primary">Take First</p>
                <div class="text-center justify-content-between d-flex">
                    <a href="<?php echo e(URL::to('instituteDashboard')); ?>" class="btn btn-danger rounded sq-btn text-white" title="Home"><i class="material-icons w-25px">home_outline</i></a>

                    <a href="<?php echo e(URL::to('instituteProfile')); ?>" class="btn btn-warning rounded sq-btn text-white" title="Profile"><i class="material-icons w-25px">account_box</i></a>

                    <a href="<?php echo e(URL::to('adminLogout/')); ?>"> 
                        <button type="button"  class="btn btn-info rounded sq-btn text-white" title="Change Password" onclick="return confirm('Are You Sure You Want To Logout ?')" ><i class="material-icons w-25px">power_settings_new</i></button>
                    </a>
                </div>

            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('institute.masterInstitute', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>